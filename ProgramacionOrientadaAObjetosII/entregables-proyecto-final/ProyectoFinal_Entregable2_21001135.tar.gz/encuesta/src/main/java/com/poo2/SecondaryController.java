package com.poo2;

public class SecondaryController {

}
